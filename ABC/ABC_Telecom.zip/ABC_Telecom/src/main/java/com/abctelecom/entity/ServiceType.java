package com.abctelecom.entity;

public enum ServiceType {

	LANDLINE, MOBILE, FIBER_OPTIC;
}

